# SA Calculator v98.98 — Tool Form Card Cleanup

## UI change
- Removed redundant outer card surfaces around active tool form groups (`.calc-card` and `.reference-form-card`).
- Preserved the Tools catalogue tiles because the supplied reference video still uses those launcher tiles.
- Preserved individual input field controls, loan/savings/BMI field surfaces, result content, quick-rate/mode controls, numeric keypad, navigation, and Settings cards.
- Kept the existing GST single-render placeholder fix from v98.97.

## Release identity
- App version: `1.99.12-v98.98`
- Android versionCode: `1099118`
- Service worker cache: `sa-calculator-v98-98-tool-form-cardless-v9898`
