import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync('index.html','utf8');
const js = fs.readFileSync('assets/js/app.js','utf8');
const css = fs.readFileSync('assets/css/tool-reference-ui.css','utf8');

 test('tool result lifecycle has one centralized invalidation path', () => {
  assert.match(js, /const TOOL_RESULT_LIFECYCLE_SCREENS = new Set\(\[/);
  assert.match(js, /function invalidateToolCalculation\(screenId = STATE\.currentScreen\)/);
  assert.match(js, /if \(key !== 'EQUAL' && key !== 'SWAP' && TOOL_RESULT_LIFECYCLE_SCREENS\.has\(STATE\.currentScreen\)\)/);
  assert.match(js, /invalidateToolCalculation\(screenId\);/);
 });

test('Age does not auto-commit after native date selection', () => {
  assert.match(html, /id="screen-agecalc" data-tool-calculated="false"/);
  assert.match(js, /Date selection is an input action, not the calculation action/);
  assert.match(js, /if \(screen\?\.dataset\.toolCalculated !== 'true'\)/);
  assert.match(js, /age-date-of-birth.*addEventListener\('change', \(\) => \{/s);
  assert.match(js, /invalidateToolCalculation\('agecalc'\)/);
});

test('BMI unit and gender changes invalidate a committed result', () => {
  assert.match(js, /invalidateToolCalculation\('bodymetrics'\);\n      calcBodyMetrics\(\);/);
  assert.match(js, /bind\('bmi-gender', \(\) => \{ invalidateToolCalculation\('bodymetrics'\)/);
  assert.match(css, /#screen-viewport #screen-bodymetrics\[data-tool-calculated="false"\]/);
});

test('GST mode, place and quick-rate changes invalidate the committed result', () => {
  const block = js.slice(js.indexOf("document.querySelectorAll('[data-gst-mode]"), js.indexOf("document.getElementById('unit-price-compare')"));
  assert.equal((block.match(/invalidateToolCalculation\('salestax'\)/g) || []).length, 3);
});

test('Loan tenure uses the compact reference label when months are zero', () => {
  assert.match(html, /id="screen-loan" data-loan-submitted="false" data-tool-calculated="false"/);
  assert.match(html, /id="loan-tenure"[\s\S]*?<span class="input-text">1years<\/span>/);
  assert.match(js, /function formatLoanTenureLabel\(years, months\)/);
  assert.match(js, /if \(m === 0\) return `\$\{y\}years`;/);
  assert.match(js, /value\.textContent = formatLoanTenureLabel\(years, months\)/);
});

test('Reference tool result surfaces stay hidden until their committed state', () => {
  for (const selector of [
    '#screen-salestax[data-tool-calculated="true"] .tool-result-content',
    '#screen-savings[data-tool-calculated="true"] .tool-result-content',
    '#screen-tip[data-tool-calculated="true"] .tip-video-results',
    '#screen-salary[data-tool-calculated="true"] .tool-result-content',
    '#screen-sip[data-tool-calculated="true"] .sip-video-results'
  ]) assert.ok(css.includes(selector), selector);
});
