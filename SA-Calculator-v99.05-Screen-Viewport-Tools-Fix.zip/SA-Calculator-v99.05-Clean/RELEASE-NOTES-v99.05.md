# SA Calculator v99.05 — Screen recovery and Tools navigation

- Fixed the Android WebView horizontal displacement caused by stray text parsed into the body as an anonymous flex item.
- Hardened app-shell and viewport widths so calculator display, keypad and navigation remain inside the phone viewport.
- Restored the missing Tools destination in the four-item bottom navigation.
- Preserved the exact 12 requested calculator tools and existing calculation systems.
- Added regression coverage and refreshed the service-worker cache namespace.
- Release: `1.99.19-v99.05`; Android versionCode: `1099134`.
