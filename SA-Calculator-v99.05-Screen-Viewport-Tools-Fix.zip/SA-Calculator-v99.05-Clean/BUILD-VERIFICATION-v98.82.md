# SA Calculator v98.82 — Build verification

## Verified locally
- Node regression suite: **99/99 passed**
- `node --check assets/js/app.js`: passed
- `node --check assets/js/localization.js`: passed
- Android web preparation script: passed (13 required web assets verified)
- Root and `www/` web assets: byte-identical
- Package / PWA manifest version: synchronized (`1.98.96-v98.82`)
- All three workflow YAML copies: parsed successfully and byte-identical
- CI service-worker cache check: corrected from stale `v9881` substring to exact `sa-calculator-v98-82-gst-keypad-audit-v9882` identity
- Workflow labels now consistently identify v98.82
- CI source/test-entry validation: 17 npm release test paths exist; all 10 workflow-required test paths exist and are included in the npm release command
- CI regression test added for exact cache namespace synchronization
- Standalone workflow, repository workflow and packaged workflow: byte-identical
- All 17 npm release test entry paths: exist
- New GST keypad / expression regression test: included in npm and workflow verification
- ZIP archive integrity: verified after packaging

## Not claimed as completed
- A physical Android device was not connected; no device-level touch, keyboard, rotation, safe-area, or frame-rate test was run.
- No local APK was built; this environment has no `adb` or Gradle executable and the source archive does not include a pre-generated Android native project.
- The supplied GitHub Actions run remains a historical failed run; this workspace cannot rewrite or rerun that run. The corrected `.github/workflows/main.yml` must be committed to the repository and a new Actions run started to verify GitHub-hosted execution.
- The supplied video is a GST Calculator recording. The standard calculator expression/result behavior was checked against source and regression tests, not against a visual recording of that screen.
